pref("extensions.ASKResults.firstrun", '0');
